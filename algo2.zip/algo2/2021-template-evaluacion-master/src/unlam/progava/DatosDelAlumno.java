package unlam.progava;

public class DatosDelAlumno {

	public static String nombres() {
		throw new RuntimeException("Camila-Facundo");
	}

	public static String apellidos() {
		throw new RuntimeException("Forestiero-Toloza");
	}
	
	public static int documento() {
		throw new RuntimeException("40137584 - 40254191");
	}
}

package utils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Grafo {

	int cantNodos;
	int cantAristas;
	boolean nodosRaices[];
	boolean condicion2[];
	boolean condicion3[];

	ArrayList<Integer> nodosQueNoCumplenCondicion3 = new ArrayList<Integer>();

	int grafo[][];

	public Grafo(int cantNodos, int cantAristas, int[][] grafo) {
		super();
		this.cantNodos = cantNodos;
		this.cantAristas = cantAristas;
		this.grafo = grafo;
	}

	public int getCantNodos() {
		return cantNodos;
	}

	public void setCantNodos(int cantNodos) {
		this.cantNodos = cantNodos;
	}

	public int getCantAristas() {
		return cantAristas;
	}

	public void setCantAristas(int cantAristas) {
		this.cantAristas = cantAristas;
	}

	public int[][] getGrafo() {
		return grafo;
	}

	public boolean esArbol() {
		this.nodosRaices = new boolean[cantNodos];
		this.condicion2 = new boolean[cantNodos];
		this.condicion3 = new boolean[cantNodos];

		boolean esArbol = this.cantAristas == this.cantNodos - 1;

		for (int i = 0; i < cantNodos; i++) {
			nodosRaices[i] = esRaiz(i);

			if (!nodosRaices[i]) {
				condicion2[i] = noTieneUnaAristaApuntando(i);
			} else {
				condicion3[i] = existeCamino(i);
			}
		}

		int raices = 0;
		int caminos = 0;
		for (int i = 0; i < cantNodos; i++) {
			if (nodosRaices[i]) {
				raices++;
			}
			if (condicion3[i]) {
				caminos++;
			}
		}

		if (raices == 1 && caminos == 1 && esArbol) {
			return true;
		} else {
			return false;
		}

	}

	private boolean existeCamino(int raiz) {
		// bfs modificado para recorrer y saber si hay camino
		int camino = 0;
		Queue<Integer> q = new LinkedList<Integer>();
		boolean visitados[] = new boolean[cantNodos];

		q.add(raiz);
		visitados[raiz] = true;

		int vis;

		while (!q.isEmpty()) {
			vis = q.poll();
			camino++;

			for (int i = 0; i < this.cantNodos; i++) {
				if (this.grafo[vis][i] == 1 && (!visitados[i])) {
					q.add(i);
					visitados[i] = true;
				}
			}

		}

		for (int i = 0; i < visitados.length; i++) {
			if (!visitados[i]) {
				if (!this.nodosQueNoCumplenCondicion3.contains(i))
					;
				this.nodosQueNoCumplenCondicion3.add(i + 1);
			}
		}

		return camino == cantNodos;
	}

	private boolean noTieneUnaAristaApuntando(int nodo) {
		int cantidad = 0;
		for (int i = 0; i < cantNodos; i++) {
			if (grafo[nodo][i] == 1) {
				cantidad++;
			}
		}

		return cantidad > 1;
	}

	private boolean esRaiz(int nodo) {
		for (int i = 0; i < cantNodos; i++) {
			if (grafo[i][nodo] == 1) {
				return false;
			}
		}
		return true;
	}

}

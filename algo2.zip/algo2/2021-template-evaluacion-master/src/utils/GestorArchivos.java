package utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GestorArchivos {

	public static Grafo leerArchivo(String path) throws FileNotFoundException {
		Scanner s = new Scanner(new File(path));
		int cantNodos;
		int cantAristas;

		cantNodos = s.nextInt();
		cantAristas = s.nextInt();

		int[][] mat = new int[cantNodos][cantNodos];

		for (int i = 0; i < cantNodos; i++) {
			for (int j = 0; j < cantNodos; j++) {
				mat[i][j] = 0;
			}
		}

		for (int i = 0; i < cantAristas; i++) {
			int ori = s.nextInt();
			int dest = s.nextInt();

			mat[ori - 1][dest - 1] = 1;
		}

		Grafo g = new Grafo(cantNodos, cantAristas, mat);

		s.close();

		return g;

	}

	public static void escribirArchivo(String path, Grafo g, boolean esArbol) throws IOException {
		try {
			PrintWriter pw = new PrintWriter(new FileWriter(path));
			if (esArbol) {
				for (int i = 0; i < g.cantNodos; i++) {
					if (g.nodosRaices[i]) {
						pw.printf("Si %d ", i + 1);
						pw.close();
						return;
					}
				}

			} else {
				pw.println("No");

				boolean cumple1 = false;
				boolean cumple3 = false;

				for (int i = 0; i < g.cantNodos; i++) {
					if (g.nodosRaices[i]) {
						pw.printf("%d ", i + 1);
						cumple1 = true;
					}

					if (g.condicion3[i]) {
						cumple3 = true;
					}
				}

				if (!cumple1) {
					pw.println("0");
				} else {
					pw.println();
				}

				//
				boolean cumple2 = true;
				for (int i = 0; i < g.cantNodos; i++) {
					if (g.condicion2[i]) {
						cumple2 = false;
						pw.printf("%d ", i + 1);
					}
				}
				if (cumple2) {
					pw.println("0");
				} else {
					pw.println();
				}

				//
				if (cumple3 || !cumple1) {
					pw.println("0");
				} else {
					for (int i = 0; i < g.nodosQueNoCumplenCondicion3.size(); i++) {
						pw.printf("%d ", g.nodosQueNoCumplenCondicion3.get(i));
					}
				}

			}
			pw.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
